# JFrog stuff

## TLS Certificates
*src/main/resources/cert*

OpenSSL requests and SAN configuration for new requests

PEM-encoded certificates and RSA keys

GlobalSign intermediate for chaining

## Licenses
*src/main/resources/licenses*

Buckets and keys for usage via Mission Control

## REST scripts

### IntelliJ IDEA scripts
*src/main/resources/rest*

These scripts are in a format executable by IntelliJ IDEA

### Ansible scripts
*src/main/ansible*

Intended to be used via ansible