#!/usr/bin/env bash
hours=${1:-168}
for x in $(curl -Lu "admin:$(cat .adminpass)" https://repo.ercot.com/artifactory/api/repositories/ | jq -r '.[] | select(.type=="REMOTE") | .key'); do
    curl -Lu "admin:$(cat .adminpass)" https://repo.ercot.com/artifactory/api/repositories/$x -H "Content-Type: application/json" -X POST -d "{\"key\": \"$x\", \"unusedArtifactsCleanupPeriodHours\": $hours}"
done
