For each repository, send repository.json to main Artifactory nodes.

For local (hosted) repositories, also send repository.json to Edge nodes, and replication.json to the opposite Artifactory and Edge nodes as the parameterized site, for each site.

e.g.

- maven-central:
  - repository.json -> artit, artib
- maven-ercot:
  - repository.json -> artit, artib, edgebd, edgebt, edgebp, edgetd, edgett, edgetp
  - replication.json -> \[repoKey=maven-ercot] for all
    - artib\[site=t]
    - artit\[site=b]
    - edgebd\[site=t.dev.edge]
    - edgetd\[site=b.dev.edge]
    - edgebt\[site=t.test.edge]
    - edgett\[site=b.test.edge]
    - edgebp\[site=t.edge]
    - edgetp\[site=b.edge]
