#!/usr/bin/env bash
function upload_jfrog_gpg_keys() {
    if [[ $1 == "-h" ]] || [[ $1 == "--help" ]]; then
        echo "Usage: upload_jfrog_gpg_keys <username> <artifactoryHost> <edgeHosts...>"
        exit
    fi
    local user
    user=$1
    shift
    local artifactory
    artifactory=$1
    local edges
    edges=("$@")

    gpg -a --export "ERCOT Release Signing" > pub.asc
    gpg -a --export-secret-keys "ERCOT Release Signing" > pri.asc
    cat > ercot-release-signing.artiedge.json <<-EOF
	{
		"alias": "ERCOT Release Signing",
		"public_key": "$(cat pub.asc)"
	}
	EOF
    cat > ercot-release-signing.dist.json <<-EOF
	{
		"public_key": "$(cat pub.asc)",
		"private_key": "$(cat pri.asc)"
	}
	EOF

    for edge in ${edges[@]}; do
        curl -u $user -X POST -H "Content-Type: application/json" -T ercot-release-signing.artiedge.json https://$edge/artifactory/api/security/keys/trusted
    done
    curl -u $user -H "Content-Type: application/json" -X PUT https://$artifactory/distribution/api/v1/keys/gpg -T ercot-release-signing.dist.json
}
upload_jfrog_gpg_keys $@
