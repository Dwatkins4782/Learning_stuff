#!/usr/bin/env bash
ansible-galaxy install -r required-roles.yaml -p ./roles