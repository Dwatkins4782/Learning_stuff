package com.ercot.jira.notifications.v1.controller;

import static org.junit.Assert.assertNotNull;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@RunWith(SpringRunner.class)
@WebMvcTest(value = NotificationController.class)
public class NotificationControllerTest {

    private static final String READ_API_ENDPOINT = "/notifications/v1/submit";

    private static final String TEST_JSON = "jira-test.json";
    
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void checkReadPuppetfile() throws Exception {
        final RequestBuilder requestBuilder = MockMvcRequestBuilders.post(String.format(READ_API_ENDPOINT)).content( Files.readString( Paths.get(new ClassPathResource(TEST_JSON).getFile().getPath()) ) ).accept(MediaType.APPLICATION_JSON);
        final MvcResult result = mockMvc.perform(requestBuilder).andExpect(MockMvcResultMatchers.status().is2xxSuccessful()).andReturn();
        assertNotNull(result);
    }
}