package com.ercot.jira.notifications;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.ercot.jira.notifications.v1.controller.NotificationControllerTest;


@RunWith(Suite.class)
@Suite.SuiteClasses({
  NotificationControllerTest.class
})
public class NotificationTestSuite {}