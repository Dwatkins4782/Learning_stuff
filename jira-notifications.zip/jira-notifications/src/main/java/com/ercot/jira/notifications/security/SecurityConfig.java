package com.ercot.jira.notifications.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;

@Configuration
@EnableWebSecurity
@PropertySource(value = {"classpath:application.properties", "classpath:notifications.properties", "file:/opt/ercot/configuration/application.properties", "file:/opt/ercot/secrets/notifications.properties"}, ignoreResourceNotFound = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    
    private static final Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

    @Value("${com.ercot.jira.notifications.secure.csrfIgnore}")
    private String csrfIgnore;

    @Value("${com.ercot.jira.notifications.secure.endpoints}")
    private String secureEndpoints;
    
    @Value("${com.ercot.jira.notifications.ldap.userBase}")
    private String userSearchBase;
    
    @Value("${com.ercot.jira.notifications.ldap.filter}")
    private String userSearchFilter;
    
    @Value("${com.ercot.jira.notifications.ldap.url}")
    private String url;
    
    @Value("${com.ercot.jira.notifications.ldap.rootDn}")
    private String rootDn;
        
    @Value("${com.ercot.jira.notifications.ldap.managerDn}")
    private String managerDn;
    
    @Value("${com.ercot.jira.notifications.ldap.managerPw}")
    private String managerPassword;

    @Override 
    protected void configure(final HttpSecurity http) throws Exception {
        final String[] endPointsArray = secureEndpoints.split(",");
                        
        http.csrf().ignoringAntMatchers(csrfIgnore)
                .and()
                .requestMatchers()
                .antMatchers(endPointsArray)
                .and()
                .authorizeRequests()
                .antMatchers(endPointsArray)
                .authenticated()
                .and()
                .httpBasic()
                .and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS);
    }

    @Override 
    protected void configure(final AuthenticationManagerBuilder auth) throws Exception {
        try {            
            final DefaultSpringSecurityContextSource ctx = new DefaultSpringSecurityContextSource(url + "/" + rootDn);
            ctx.setUserDn(managerDn);
            ctx.setPassword(managerPassword);
            ctx.setReferral("follow");
            ctx.afterPropertiesSet();
            
            auth.ldapAuthentication()
                    .userSearchFilter(userSearchFilter)
                    .userSearchBase(userSearchBase)
                    .contextSource(ctx);
        }
        catch (Exception ex) {
            logger.error("Error attempting to configure LDAP authentication.");
            throw ex;
        }
    }
}