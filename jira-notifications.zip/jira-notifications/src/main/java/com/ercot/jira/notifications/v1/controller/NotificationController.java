package com.ercot.jira.notifications.v1.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ercot.jira.notifications.v1.data.TicketHandler;

import io.prometheus.client.Counter;
import io.prometheus.client.Histogram;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;

@RestController
@OpenAPIDefinition(info = @Info(title = "Notifications", description = "Webhook for monitoring the lifecycle of Jira Issues", version = "v0.0.2", license = @License(name = "ERCOT", url = "http://www.ercot.com")))
@PropertySource(value = {"classpath:application.properties", "classpath:notifications.properties", "file:/opt/ercot/configuration/application.properties", "file:/opt/ercot/secrets/notifications.properties"}, ignoreResourceNotFound = true)
public class NotificationController {

    private static final Logger logger = LoggerFactory.getLogger(NotificationController.class);

    private static final Histogram NOTIFICATIONS_LATENCY_HISTOGRAM = Histogram.build().name("NotificationsLatencyHistogram").help("Latency Histogram for Notifications Calls").register();

    private static final Histogram NOTIFICATIONS_EVENT_LATENCY_HISTOGRAM = Histogram.build().name("NotificationsCreateLatencyHistogram").help("Latency Histogram for NotificationsController.submitJiraIssueEvent Calls").register();
    private static final Counter EVENT_COUNTER = Counter.build().name("NotificationsCreateCounter").help("Counter for submitJiraIssueEvent Calls").register();
     
    @Value( "${com.ercot.jira.notifications.keys.issue:issue}" )
    private String issueKey;
    
    @Value( "${com.ercot.jira.notifications.keys.id:key}" )
    private String idKey;
 
    @Value( "${com.ercot.jira.notifications.username:jenkins}" )
    private String jenkinsUsername;
    
    @Value( "${com.ercot.jira.notifications.token}" )
    private String jenkinsToken;
    
    @Value( "${com.ercot.jira.notifications.jenkins.url}" )
    private String jenkinsInstanceUrl;
    
    @Value( "${com.ercot.jira.notifications.jenkins.buildEndpoint}" )
    private String buildEndpoint;
    
    @Operation(summary = "Submit a Jira Ticket Notification/Event.")
    @PostMapping(value = {"/notifications/v1/submit"}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    public void submitJiraImplementationEvent(@RequestBody String jsonPayload) {
        if(logger.isInfoEnabled()) {
            logger.info("Incoming request for /notifications/v1/submit/");
        }

        try(Histogram.Timer timer = NOTIFICATIONS_LATENCY_HISTOGRAM.startTimer();
            Histogram.Timer createTimer = NOTIFICATIONS_EVENT_LATENCY_HISTOGRAM.startTimer()) {
            EVENT_COUNTER.inc();
            
            final TicketHandler th = new TicketHandler(jsonPayload, issueKey, idKey, jenkinsInstanceUrl + buildEndpoint);
            th.execute(jenkinsUsername, jenkinsToken);
          
            if(logger.isInfoEnabled()) {
                logger.info("Jira Notification Event: \n" + th.toString());
                logger.info("Finishing request for /notifications/v1/submit/ took " + timer.observeDuration());
            }
            NOTIFICATIONS_LATENCY_HISTOGRAM.observe(timer.observeDuration());
            NOTIFICATIONS_EVENT_LATENCY_HISTOGRAM.observe(createTimer.observeDuration());
        }
    }
}