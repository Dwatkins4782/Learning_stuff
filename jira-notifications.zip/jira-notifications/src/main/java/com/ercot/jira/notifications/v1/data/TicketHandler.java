package com.ercot.jira.notifications.v1.data;

import java.util.Objects;
import java.nio.charset.StandardCharsets;

import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

public class TicketHandler {
        
    private static final int SPACES_IN_TAB = 4;
    private static final String TICKET_ID_FIELD = "TICKET_ID";
    private static final String AUTHENTICATION_HEADER = "Authorization";
    private static final String AUTHENTICATION_HEADER_TYPE = "Basic ";
    
    private String id;
    private String pretty;
    private String raw;
    private String jobUrl;
    
    public TicketHandler(final String json, final String issueKey, final String idKey, final String jbUrl) {
        if(json != null) {
            final JSONObject jsonObject = new JSONObject(json);
            final JSONObject issueObject = jsonObject.getJSONObject(issueKey);

            id = issueObject.getString(idKey);
            pretty = jsonObject.toString(SPACES_IN_TAB);
            raw = json;
            jobUrl = jbUrl;
        } else {
            throw new IllegalStateException("Ticket json must be non-null");
        }
    }

    public String getId() {
        return id;
    }

    public String getPretty() {
        return pretty;
    }

    public String getRaw() {
        return raw;
    }

    public String getJobUrl() {
        return jobUrl;
    }
    
    public int execute(final String username, final String password) {
        int retval = -1;
        
        if(getJobUrl() != null && !getJobUrl().isEmpty() && username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
            
            retval = submitJob(getJobUrl(), username, password);
        }
        
        return retval;
    }
    
    private HttpHeaders createHeaders(final String username, final String password) {
        HttpHeaders retval = new HttpHeaders();

        final String auth = username + ":" + password;
        final byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII) );
        String authHeader = AUTHENTICATION_HEADER_TYPE + new String( encodedAuth, StandardCharsets.US_ASCII);
        retval.set(AUTHENTICATION_HEADER, authHeader);
        retval.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            
        return retval;
    }
    
    protected int submitJob(final String jobUrl, final String username, final String password) {
        int retval = -1;
        final RestTemplate template = new RestTemplate();
        
        final MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add(TICKET_ID_FIELD, getId());
 
        final ResponseEntity<String> response = template.exchange(jobUrl, HttpMethod.POST, new HttpEntity<MultiValueMap<String, String>>(map, createHeaders(username, password)), String.class);
        
        if(response != null) {
            retval = response.getStatusCodeValue();
        }
        
        return retval;
    }
       
    @Override
    public int hashCode() {
        return Objects.hash(id, pretty, raw, jobUrl);
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TicketHandler)) {
            return false;
        }
        TicketHandler other = (TicketHandler) obj;
        return Objects.equals(pretty, other.pretty) && Objects.equals(raw, other.raw)
            && Objects.equals(jobUrl, other.jobUrl);
    }
    
    @Override
    public String toString() {
        return "TicketHandler [getId()=" + getId() + ", getJobUrl()=" + getJobUrl() + "]";
    }
}
